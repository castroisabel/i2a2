# Dicionário de Dados - Base de Compras da Empresa

Este dicionário descreve os arquivos e campos contidos na base de dados de compras institucionais.

## Tabela: compras.csv
Representa os registros individuais de pedidos de compras efetuados no período de Janeiro a Julho de 2024.

| Coluna | Tipo | Descrição | Exemplo |
| :--- | :--- | :--- | :--- |
| `id_compra` | Inteiro | Código numérico identificador da compra | 1, 2, 3 |
| `data_compra` | Data (AAAA-MM-DD) | Data em que o pedido foi realizado | 2024-01-10 |
| `fornecedor` | Texto | Nome da empresa fornecedora contratada | TechSolutions Ltda |
| `produto` | Texto | Nome do produto ou serviço adquirido | Licença Software Cloud |
| `categoria` | Texto | Categoria do item (TI & Tecnologia, Consultoria, Logística, Segurança, Suprimentos) | TI & Tecnologia |
| `quantidade` | Inteiro | Quantidade física de unidades adquiridas | 20 |
| `valor_total` | Decimal | Valor total gasto na aquisição em Reais (R$) | 30000.00 |
